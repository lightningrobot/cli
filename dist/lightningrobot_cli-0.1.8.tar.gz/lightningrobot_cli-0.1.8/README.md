# 闪电机器人-脚手架
点[这里](https://lightningrobot.github.io/guide/quick-start.html)查看使用方法。